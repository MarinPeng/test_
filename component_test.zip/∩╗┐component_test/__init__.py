# -*- coding: utf-8 -*-

__requirements__ = [
    "faker", # 特定版本号
    "selenium==3.14.1", # 不限制版本号
]